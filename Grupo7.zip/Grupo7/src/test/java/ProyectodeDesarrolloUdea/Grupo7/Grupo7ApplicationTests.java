package ProyectodeDesarrolloUdea.Grupo7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Grupo7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
