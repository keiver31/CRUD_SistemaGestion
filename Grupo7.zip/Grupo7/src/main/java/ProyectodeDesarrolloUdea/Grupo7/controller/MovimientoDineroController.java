package ProyectodeDesarrolloUdea.Grupo7.controller;


import ProyectodeDesarrolloUdea.Grupo7.entity.Empleado;
import ProyectodeDesarrolloUdea.Grupo7.entity.MovimientoDinero;
import ProyectodeDesarrolloUdea.Grupo7.service.MovimientoDineroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

//@RestController
@Controller
//@RequestMapping(path="api/v1/movimientoDinero")
public class MovimientoDineroController {


    @Autowired
    private MovimientoDineroService movimientoDineroService;

    @GetMapping("/allMovimientos")
    public String getMovimientos(Model model){
        List<MovimientoDinero>movimientos= movimientoDineroService.getMovimientosDinero();
        model.addAttribute("movimientos", movimientos);
        return "indexMovimientos";
    }

    @GetMapping("/addMovimiento")
    public String Agregar(Model model){
        model.addAttribute("movimiento", new MovimientoDinero());
        return "newMovimiento";
    }

    @PostMapping("/saveMovimiento")
    public String saveMovimiento(@ModelAttribute MovimientoDinero movimientoDinero, Model model){
        movimientoDineroService.saveOrUpdate(movimientoDinero);
        return "redirect:/allMovimientos";
    }

    @GetMapping("/eliminarMovimiento/{id}")
    public String delete(Model model, @PathVariable Long id){
        movimientoDineroService.delete(id);
        return "redirect:/allMovimientos";
    }




    /*
    @GetMapping
    public List<MovimientoDinero> getAll(){

        return movimientoDineroService.getMovimientosDinero();
    }

     */

    /*
    @GetMapping("/{id}")
    public Optional<MovimientoDinero> getById(@PathVariable("id") Long id){
        return movimientoDineroService.getMovimientoDinero(id);
    }

    @PostMapping
    public void saveUpdate(@RequestBody MovimientoDinero movimientoDinero){
        movimientoDineroService.saveOrUpdate(movimientoDinero);
    }

    @PutMapping("/updateMovimientoDinero")
    public MovimientoDinero updateMovimientoDinero(@RequestBody MovimientoDinero movimientoDinero){

        return movimientoDineroService.updateMovimientoDinero(movimientoDinero);
    }




    @DeleteMapping("/{id}")
    public void saveUpdate(@PathVariable("id") Long id){
        movimientoDineroService.delete(id);
    }

     */
}

