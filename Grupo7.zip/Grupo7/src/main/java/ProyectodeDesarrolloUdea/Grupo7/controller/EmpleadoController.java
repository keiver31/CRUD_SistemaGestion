package ProyectodeDesarrolloUdea.Grupo7.controller;


import ProyectodeDesarrolloUdea.Grupo7.entity.Empleado;
import ProyectodeDesarrolloUdea.Grupo7.entity.Empresa;
import ProyectodeDesarrolloUdea.Grupo7.service.EmpleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.view.RedirectView;

import java.util.List;
import java.util.Optional;

//@RestController
@Controller
//@RequestMapping(path="api/v1/empleado")
public class EmpleadoController {


    @Autowired
    private EmpleadoService empleadoService;

    //new 06-11
    @GetMapping("/allEmpleados")
    public String getEmpleados(Model model){
        List<Empleado>empleados= empleadoService.getEmpleados();
        model.addAttribute("empleados", empleados);
        return "indexEmpleado";
    }

    @GetMapping("/addEmpleado")
    public String Agregar(Model model){
        model.addAttribute("empleado", new Empleado());
        return "newEmpleado";
    }
    
    @PostMapping("/saveEmpleado")
    public String saveEmpleado(@ModelAttribute Empleado empleado, Model model){
        empleadoService.saveOrUpdate(empleado);
        return "redirect:/allEmpleados";
    }


    /*
    @GetMapping("/edit/{id}")
    public String editEmpleado(@PathVariable Long id, Model model){
        Optional<Empleado> empleado=empleadoService.getEmpleado(id);
        //model.addAttribute("empleado", empleado);
        //return "editEmpleado";

        if (empleado.isPresent()){
            //Empleado empleado=empleadovf.get();
            model.addAttribute("empleado", empleado);
            return "editEmpleado";
        } else{
            return "redirect:/allEmpleado";
        }


    }

     */


    @GetMapping("/eliminar/{id}")
    public String delete(Model model, @PathVariable Long id){
        empleadoService.delete(id);
        return "redirect:/allEmpleados";
    }

    @GetMapping
    public List<Empleado> getAll(){
        return empleadoService.getEmpleados();
    }


    @GetMapping("/{id}")
    public Optional<Empleado> getById(@PathVariable("id") Long id){

        return Optional.ofNullable(empleadoService.getEmpleado(id));
    }

    @PostMapping
    public void saveUpdate(@RequestBody Empleado empleado){
        empleadoService.saveOrUpdate(empleado);
    }

    @PostMapping("/empleado/update")
    public RedirectView updateEmpleado(@ModelAttribute Empleado empleado){
        empleado.setRole("Operativo");
        empleadoService.updateEmpleado(empleado);
        return new RedirectView("/allEmpleados");
    }

    @DeleteMapping("/{id}")
    public void saveUpdate(@PathVariable("id") Long id){
        empleadoService.delete(id);
    }
}
