package ProyectodeDesarrolloUdea.Grupo7.controller;

import ProyectodeDesarrolloUdea.Grupo7.entity.Empleado;
import ProyectodeDesarrolloUdea.Grupo7.entity.Empresa;
import ProyectodeDesarrolloUdea.Grupo7.service.EmpleadoService;
import ProyectodeDesarrolloUdea.Grupo7.service.EmpresaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Optional;

@Controller
public class FrontController {

    @Autowired
    EmpresaService empresaService;
    EmpleadoService empleadoService;

    @GetMapping("/empresas")
    public String empresa(Model model){
        List<Empresa> empresas = empresaService.getEmpresas();
        model.addAttribute("empresas", empresas);
        return "empresa";
    }

    @GetMapping("/empresas/newEmpresa")
    public String newEmpresa(Model model){
        model.addAttribute("empresas", new Empresa());
        return "newEmpresa";
    }

    @GetMapping("/empresa/edit/{id}")
    public String editEmpresa(@PathVariable long id, Model model){
        Empresa empresa = empresaService.getEmpresaById(id);
        if (empresa != null){
            model.addAttribute("empresa", empresa);
            return "editEmpresa";
        } else {
            return "redirect:/empresas";
        }
    }


    /*
    @GetMapping("/empleado/edit/{id}")
    public String editEmpleado(@PathVariable long id, Model model){
        Empleado empleado = empleadoService.getEmpleado(id);
        if (empleado != null){
            model.addAttribute("empleado", empleado);
            return "editEmpleado";
        } else {
            return "redirect:/empleados";
        }
    }

     */


    /*
    @GetMapping("/edit/{id}")
    public String editEmpleado(@PathVariable long id, Model model){
        Optional<Empleado> empleado=empleadoService.getEmpleado(id);
        if (empleado.isPresent()){
            model.addAttribute("empleado", empleado);
            return "editEmpleado";
        } else{
            return "redirect:/allEmpleados";
        }

    }

     */



}
